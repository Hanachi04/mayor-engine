"""
Ollama adapter for the sentiment agent.

Design decisions locked in during the original build (kept here verbatim):
  - Model default: qwen2.5:3b (llama3.2:1b was tried first and hallucinated
    numeric readings 0/5 times on a spot check; qwen2.5:3b scored 4/5).
  - Only technical/price-action fields are sent (NOT market_cap/volume) —
    sending fundamentals fields caused the sentiment agent to reason about
    "missing market cap" instead of price action.
  - The prompt explicitly forbids referencing fields that were not provided.
  - reflection_context is optional, advisory-only text injected from the
    risk-memory layer (Layer 5). It must never change the numeric snapshot
    or be treated as authoritative — it is a warning, not an instruction.
"""
import json
import os
import urllib.request

OLLAMA_HOST = os.environ.get("OLLAMA_HOST", "http://127.0.0.1:11434")
OLLAMA_MODEL = os.environ.get("OLLAMA_MODEL", "qwen2.5:3b")

_SYSTEM_PROMPT = (
    "You are a technical sentiment classifier. Base your judgment ONLY on "
    "price action and momentum indicators provided (RSI, MACD, Bollinger "
    "Bands, volatility). Do not reference market cap, fundamentals, or any "
    "data not provided. Return JSON only with exactly: label (bullish, "
    "bearish, or neutral), score (-1 to 1), and reason."
)

_TECHNICAL_FIELDS = (
    "symbol", "close", "open", "high", "low",
    "rsi", "macd", "macd_signal", "bb_lower", "bb_mid", "bb_upper",
    "volatility",
)


def _build_prompt(snapshot: dict, reflection_context: str | None) -> str:
    technical_snapshot = {k: snapshot[k] for k in _TECHNICAL_FIELDS if k in snapshot}
    parts = [_SYSTEM_PROMPT]
    if reflection_context:
        parts.append(
            "Prior execution reflection is advisory context only; do not "
            "override the current indicators:\n" + reflection_context
        )
    parts.append("Snapshot: " + json.dumps(technical_snapshot, sort_keys=True))
    return "\n\n".join(parts)


def classify(snapshot: dict, reflection_context: str | None = None,
             transport=None) -> dict:
    """
    transport: optional callable(prompt: str) -> str, used to inject a fake
    HTTP layer in tests without a real Ollama server. Production code path
    (transport=None) calls the real local Ollama HTTP API.
    """
    prompt = _build_prompt(snapshot, reflection_context)

    if transport is not None:
        raw_text = transport(prompt)
    else:
        payload = json.dumps({
            "model": OLLAMA_MODEL,
            "prompt": prompt,
            "stream": False,
            "format": "json",
            "options": {"temperature": 0.0},
        }).encode("utf-8")
        req = urllib.request.Request(
            f"{OLLAMA_HOST}/api/generate",
            data=payload,
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=60) as resp:
            body = json.loads(resp.read().decode("utf-8"))
        raw_text = body["response"]

    result = json.loads(raw_text)
    result["score"] = max(-1.0, min(1.0, float(result["score"])))
    if result["label"] not in {"bullish", "bearish", "neutral"}:
        raise ValueError(f"invalid sentiment label: {result['label']!r}")
    return result
