# NOTE: "analyst-council" (this layer's own directory name) contains a
# hyphen, which is not a valid Python package identifier — it can never be
# part of a dotted import path (`from ..adapters import x` is impossible).
# Every layer is therefore run with its OWN folder as the sys.path root
# (main.py does this once, at process start), and internal modules
# (agents, adapters, persistence — all valid identifiers) are imported as
# plain top-level absolute imports, exactly as below.
from adapters import ollama as ollama_adapter


def sentiment_node(state: dict) -> dict:
    snapshot = state["snapshot"]
    reflection_context = state.get("reflection_context")
    try:
        result = ollama_adapter.classify(snapshot, reflection_context=reflection_context)
    except Exception as exc:
        result = {
            "label": "neutral",
            "score": 0.0,
            "reason": f"sentiment unavailable: {type(exc).__name__}: {exc}",
        }
    return {"sentiment": result}
