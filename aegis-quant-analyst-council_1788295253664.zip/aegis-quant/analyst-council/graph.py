from langgraph.graph import END, START, StateGraph

from state import CouncilState
from agents.fundamentals import fundamentals_node
from agents.sentiment import sentiment_node
from agents.technicals import technicals_node


def aggregate_node(state: dict) -> dict:
    views = [state["fundamentals"]["view"], state["sentiment"]["label"], state["technicals"]["view"]]
    bullish = views.count("bullish")
    bearish = views.count("bearish")
    if bullish > bearish:
        decision = "LONG"
    elif bearish > bullish:
        decision = "SHORT"
    else:
        decision = None
    return {"council_decision": decision, "risk_pct": 0.35 if decision else 0.0}


def build_graph():
    graph = StateGraph(CouncilState)
    graph.add_node("fundamentals", fundamentals_node)
    graph.add_node("sentiment", sentiment_node)
    graph.add_node("technicals", technicals_node)
    graph.add_node("aggregate", aggregate_node)

    graph.add_edge(START, "fundamentals")
    graph.add_edge(START, "sentiment")
    graph.add_edge(START, "technicals")
    graph.add_edge("fundamentals", "aggregate")
    graph.add_edge("sentiment", "aggregate")
    graph.add_edge("technicals", "aggregate")
    graph.add_edge("aggregate", END)
    return graph.compile()
