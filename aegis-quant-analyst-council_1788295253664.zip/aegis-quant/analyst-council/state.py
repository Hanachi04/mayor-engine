from typing import TypedDict, Any


class CouncilState(TypedDict, total=False):
    symbol: str
    as_of: int
    snapshot: dict[str, float]
    fundamentals: dict[str, Any]
    sentiment: dict[str, Any]
    technicals: dict[str, Any]
    council_decision: str | None
    risk_pct: float
    sqlite_decision_id: int
    errors: list[str]
